//В качестве пунктов меню предложить: «Боевик», «Детектив», «Мелодрама», «Ужасы», «Комедия», «Фантастика», «Выход». 
//Подтверждение выбранного пункта меню реализовать по клавише «y». 
//Реализовать «пролистывание» с переходом через границы 
//(стрелка вверх на элементе с нулевым индексом переводит курсор на элемент с последним индексом и стрелка вниз на элементе с последним индексом переводит курсор на элемент с нулевым индексом).
//Цветовая схема консоли: белый фон, чёрный шрифт. Цветовая схема курсора: зелёный фон, белый шрифт.
using System;

namespace ConsoleMenu
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] menuItems = { "Боевик", "Детектив", "Мелодрама", "Ужасы", "Комедия", "Фантастика", "Выход" };
            int selectedItem = 0;
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            while (true)
            {
                Console.Clear();
                for (int i = 0; i < menuItems.Length; i++)
                {
                    if (i == selectedItem)
                    {
                        Console.BackgroundColor = ConsoleColor.Green;
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.White;
                        Console.ForegroundColor = ConsoleColor.Black;
                    }
                    Console.WriteLine(menuItems[i]);
                }
                ConsoleKeyInfo keyInfo = Console.ReadKey();
                if (keyInfo.Key == ConsoleKey.UpArrow)
                {
                    selectedItem--;
                    if (selectedItem < 0)
                    {
                        selectedItem = menuItems.Length - 1;
                    }
                }
                else if (keyInfo.Key == ConsoleKey.DownArrow)
                {
                    selectedItem++;
                    if (selectedItem == menuItems.Length)
                    {
                        selectedItem = 0;
                    }
                }
                else if (keyInfo.Key == ConsoleKey.Y)
                {
                    if (selectedItem == menuItems.Length - 1)
                    {
                        break;
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Вы выбрали: " + menuItems[selectedItem]);
                        Console.ReadKey();
                    }
                }
            }
        }
    }
}