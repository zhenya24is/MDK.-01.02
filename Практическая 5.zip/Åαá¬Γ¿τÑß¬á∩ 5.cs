//В тексте во втором предложении после слов «Ура» поставить «!!!».
//Если «Ура» встречается в любом другом предложении, то оставить его без изменений.
//В качестве текста для тестового примера (тестовых примеров) взять не менее трёх предложений. 
string text = "Сегодня на улице так хорошо. Ура, выходной.Надо пойти на прогулку.";
string[] sentences = text.Split('.');
foreach (string sentence in sentences)
{
    if (sentence.Contains("Ура"))
    {
        if (sentence.StartsWith("Ура"))
        {
            Console.WriteLine("Ура!!!");
        }
        else
        {
            Console.WriteLine(sentence);
        }
    }
    else
    {
        Console.WriteLine(sentence);
    }
}