//22 Вариант. Соколов Евгений Александрович. Текстовый файл содержит строки, в каждой из которых записана пара значений целого или вещественного типа, 
//отделённых друг от друга пробелами и текстовыми надписями с действиями, 
//например «прибавить», «умножить», «разделить», «вычесть».
//В новый файл записать результаты выполнения указанных действий, разделённые пробелами.
//Для вещественных результатов сохранить только 5 знаков после плавающей запятой. 
using System;
using System.IO;

class Program
{
    static void Main()
    {
        string inputFile = "input.txt";
        string outputFile = "output.txt";

        using (StreamReader reader = new StreamReader(inputFile))
        using (StreamWriter writer = new StreamWriter(outputFile))
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                string[] parts = line.Split(' ');

                double a = double.Parse(parts[0]);
                double b = double.Parse(parts[2]);
                string action = parts[1];

                double result;

                switch (action)
                {
                    case "прибавить":
                        result = a + b;
                        break;
                    case "вычесть":
                        result = a - b;
                        break;
                    case "умножить":
                        result = a * b;
                        break;
                    case "разделить":
                        result = a / b;
                        break;
                    default:
                        throw new ArgumentException($"Неизвестное действие: {action}");
                }

                writer.Write($"{result:f5} ");
            }
        }
    }
}

